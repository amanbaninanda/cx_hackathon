# database_service.py

import pandas as pd
import psycopg2 # You would typically use psycopg2 or SQLAlchemy for Redshift
from sqlalchemy import create_engine, text # Added 'text' import
import streamlit as st # Imported for st.spinner and st.error in placeholder

# Placeholder for database credentials - these would ideally come from
# environment variables or Streamlit secrets in a real application.
DB_HOST = "wsprod-pantheon-redshift-c9qtpydth0xz.ws1.us-east-1.a.p1.satoricyber.net"
DB_PORT = 5439 # Default Redshift port
DB_NAME = "pantheon"
DB_USER = ""
DB_PASSWORD = ""

def get_db_engine():
    """Constructs and returns a SQLAlchemy engine for Redshift."""
    try:
        # Construct the connection string for SQLAlchemy
        # For Redshift, it's typically 'postgresql+psycopg2://user:password@host:port/dbname'
        db_connection_str = f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
        engine = create_engine(db_connection_str)
        return engine
    except Exception as e:
        st.error(f"Failed to create database engine: {e}. Check your DB credentials.")
        return None


def execute_sql_query(sql_query: str) -> pd.DataFrame:
    """
    Executes a SQL query against the Redshift database and returns results as a pandas DataFrame.
    This is a placeholder function. You will need to implement the actual database connection logic here.
    """
    st.info("Executing database query...")
    
    engine = get_db_engine()
    if engine is None:
        return pd.DataFrame() # Return empty if engine creation failed
    
    try:
        with engine.connect() as connection:
            result = connection.execute(text(sql_query))
            rows = result.fetchall()
            columns = result.keys()
            
            # Create DataFrame with proper column names
            df = pd.DataFrame(rows, columns=columns)
            
            print(f"Query executed successfully. Rows returned: {len(df)}")
            print(f"SQL Query: {sql_query}")
            if not df.empty:
                print(f"First few rows:\n{df.head()}")
            
            return df
            
    except Exception as e:
        print(f"Error executing query: {e}")
        st.error(f"Database error: {e}")
        return pd.DataFrame()  # Return empty DataFrame on error
    
    
def fetch_db_schema(target_schema: str = 'public', table_names: list = None) -> str:
    """
    Fetches the database schema dynamically for specified tables within a given schema.
    
    Args:
        target_schema (str): The name of the database schema (e.g., 'public', 'client_experience').
        table_names (list, optional): A list of table names to fetch schema for.
                                      If None, fetches schema for all tables in target_schema.

    Returns:
        str: A formatted string representation of the schema for the LLM.
    """
    st.info(f"Fetching database schema for schema: {target_schema}, tables: {table_names if table_names else 'all' }...")
    
    
    try:
        conn = psycopg2.connect(
            host=DB_HOST, port=DB_PORT, database=DB_NAME, user=DB_USER, password=DB_PASSWORD
        )
        cursor = conn.cursor()
    
        # Build the base query for columns
        query = """
            SELECT table_name, column_name, data_type
            FROM information_schema.columns
            WHERE table_schema = %s
        """
        params = [target_schema]
    
        # Add table name filter if provided
        if table_names:
            # Create a string of placeholders for the IN clause (e.g., '%s, %s')
            placeholders = ', '.join(['%s'] * len(table_names))
            query += f" AND table_name IN ({placeholders})"
            params.extend(table_names)
    
        query += " ORDER BY table_name, ordinal_position;"
    
        print(f"Schema query: {query}")
        print(f"Schema params: {params}")
        
        cursor.execute(query, params)
        schema_rows = cursor.fetchall()
        
        print(f"Schema rows found: {len(schema_rows)}")
        
        conn.close()
    
        # Process schema_rows to format it for the LLM
        formatted_schema = "Tables:\n"
        current_table = None
        for row in schema_rows:
            table_name, column_name, data_type = row
            if table_name != current_table:
                if current_table:
                    formatted_schema += ")\n"
                formatted_schema += f"- {target_schema}.{table_name} (\n"
                current_table = table_name
            formatted_schema += f"    {column_name} {data_type},\n"
        if current_table:
            formatted_schema = formatted_schema.rstrip(',\n') + "\n)" # Remove last comma and add closing paren
        else: # No tables found for the given criteria
            formatted_schema += "  (No tables found for specified criteria.)\n"
        
        print(f"Formatted schema:\n{formatted_schema}")
    
        return formatted_schema
    except Exception as e:
        error_msg = f"Failed to fetch database schema: {e}"
        st.error(error_msg)
        print(error_msg)
        return f"Error fetching schema: {e}. Please check database connection and table names."
