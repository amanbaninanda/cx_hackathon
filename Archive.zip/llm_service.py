# llm_service.py
import requests
import json
import re
from config import API_URL, LLM_API_KEY, DEFAULT_LLM_MODEL # Removed DATABASE_SCHEMA import

def call_llm_api(chat_history, database_schema_text):
    """
    Calls the LLM API with the current chat history and a system prompt
    containing the dynamically fetched database schema.

    Args:
        chat_history (list): A list of message dictionaries (e.g., [{"role": "user", "content": "..."}]).
        database_schema_text (str): The dynamically fetched and formatted database schema.

    Returns:
        str: The generated text response from the LLM.
    """
    messages_payload = []

    system_instruction = (
        "You are an expert SQL generator for a Redshift database. "
        "Your goal is to convert natural language questions into accurate SQL queries. "
        "You have knowledge of the following database schema and metrics:\n\n"
        f"{database_schema_text}\n\n" # Use the dynamically passed schema
        "When generating SQL, always wrap it in a markdown code block (```sql ... ```). "
        "Also add the schema name to all the tables in the SQL query."
        "If you need more information from the user, ask clarifying questions. "
        "Do not execute the SQL, only generate it."
        "Only respond with the SQL query when the user is satisfied with the SQL."
        "Otherwise, keep the conversation going to clarify the requirements."
    )

    messages_payload.append({"role": "system", "content": system_instruction})

    for msg in chat_history:
        messages_payload.append({"role": msg["role"], "content": msg["content"]})

    payload = {
        "model": DEFAULT_LLM_MODEL,
        "messages": messages_payload
    }

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LLM_API_KEY}"
    }

    try:
        response = requests.post(API_URL, headers=headers, data=json.dumps(payload))
        response.raise_for_status() # Raise an HTTPError for bad responses (4xx or 5xx)
        result = response.json()

        if result and result.get("choices") and len(result["choices"]) > 0 and \
           result["choices"][0].get("message") and result["choices"][0]["message"].get("content"):
            return result["choices"][0]["message"]["content"]
        else:
            print(f"Unexpected LLM API response: {result}") # For debugging
            return "Sorry, I couldn't generate a response. The API response was unexpected."

    except requests.exceptions.RequestException as e:
        print(f"Error making API request to LLM: {e}") # For debugging
        return f"Error connecting to LLM: {e}"
    except json.JSONDecodeError:
        print(f"Error decoding JSON from LLM response: {response.text}") # For debugging
        return "Error: Failed to parse JSON response from API."
    except Exception as e:
        print(f"An unexpected error occurred during LLM call: {e}") # For debugging
        return f"An unexpected error occurred: {e}"

def extract_sql_from_response(text):
    """
    Extracts SQL code blocks from the LLM's response.
    Expects SQL to be wrapped in ```sql ... ``` markdown.
    """
    match = re.search(r"```sql\n(.*?)```", text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return None
