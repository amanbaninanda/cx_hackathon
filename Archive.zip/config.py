# config.py

# --- Configuration ---
# API endpoint for the Gemini 2.0 Flash model.
# The API key is securely injected by the Canvas environment at runtime.
API_URL = "https://llm.w10e.com/api/chat/completions"
LLM_API_KEY = "" 

# Default model to use for chat completions.
DEFAULT_LLM_MODEL = "rosettasql"

