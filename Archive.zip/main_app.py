# main_app.py
import streamlit as st
import uuid
from llm_service import call_llm_api, extract_sql_from_response
from database_service import execute_sql_query, fetch_db_schema # Import fetch_db_schema

# --- Streamlit UI Setup ---
st.set_page_config(page_title="Text-to-SQL Data Explorer", layout="centered")
st.title("📊 Text-to-SQL Data Explorer")
st.markdown("Ask me questions about your data, and I'll generate SQL for you!")
st.markdown("---")

# Initialize session state variables if they don't exist
if "messages" not in st.session_state:
    st.session_state.messages = []
if "user_id" not in st.session_state:
    st.session_state.user_id = str(uuid.uuid4())
if "generated_sql" not in st.session_state:
    st.session_state.generated_sql = None
if "awaiting_confirmation" not in st.session_state:
    st.session_state.awaiting_confirmation = False
if "query_results_df" not in st.session_state:
    st.session_state.query_results_df = None
if "db_schema" not in st.session_state:
    st.session_state.db_schema = None

# --- Fetch Database Schema (only once) ---
# This ensures the schema is loaded at the start of the session
if st.session_state.db_schema is None:
    with st.spinner("Fetching database schema..."):
        # Example: Fetch schema only for 'employees', 'sales', 'departments' from 'public' schema
        # You can customize target_schema and table_names as needed for your Redshift instance.
        st.session_state.db_schema = fetch_db_schema(
            target_schema='client_experience', # Your specific schema name
            table_names=['dim_cs_agent_scorecard', 'cxo_dim_phone_ticket_interactions', 'dim_ticket_demand','dim_ticket_summary','dim_ticket_summary_slim'] # Your list of desired tables
        )
    if "Error" in st.session_state.db_schema: # Check if fetching returned an error message
        st.error(f"Failed to load database schema: {st.session_state.db_schema}. Please check your database_service.py.")
        st.stop() # Stop execution if schema cannot be loaded


# --- Display Chat History ---
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
    # If the message role is 'data' and it contains DataFrame, display it
    if message["role"] == "data" and isinstance(message["content"], str) and "Query results displayed below." in message["content"]:
        # Display the DataFrame as a table if it's stored
        if st.session_state.query_results_df is not None:
            st.dataframe(st.session_state.query_results_df)

# --- Function to get LLM explanation ---
def get_sql_explanation(sql_query):
    """
    Sends the SQL query to the LLM to get a natural language explanation.
    """
    explanation_prompt = (
        f"Explain the following SQL query in simple terms:\n\n"
        f"SQL Query:\n```sql\n{sql_query}\n```\n\n"
        "Provide a concise explanation of what it does and what data it retrieves, "
        "referencing the provided database schema (employees, departments, sales tables)."
    )
    
    # For explanation, we only need to send the specific explanation prompt.
    temp_chat_for_explanation = [{"role": "user", "content": explanation_prompt}]
    
    # Pass the dynamically fetched schema to call_llm_api
    explanation_text = call_llm_api(temp_chat_for_explanation, st.session_state.db_schema)
    return explanation_text

# --- SQL Confirmation UI ---
# This block now appears independently based on awaiting_confirmation state
if st.session_state.awaiting_confirmation and st.session_state.generated_sql:
    st.markdown("---")
    st.markdown("### Confirm SQL Query")
    st.code(st.session_state.generated_sql, language="sql")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("✅ Confirm and Run Query"):
            st.session_state.messages.append({"role": "assistant", "content": "User confirmed the SQL. Running query..."})
            with st.spinner("Executing query and fetching data..."):
                try:
                    query_df = execute_sql_query(st.session_state.generated_sql)
                    print(query_df)
                    st.session_state.query_results_df = query_df
                    
                    if not query_df.empty:
                        st.success("Query executed successfully! Here are the results:")
                        st.dataframe(query_df)
                        csv = query_df.to_csv(index=False).encode('utf-8')
                        st.download_button(
                            label="Download Data as CSV",
                            data=csv,
                            file_name="query_results.csv",
                            mime="text/csv",
                        )
                        st.markdown("*(Graph generation functionality to be added here)*")
                        st.session_state.messages.append({"role": "data", "content": "Query results displayed below."})
                    else:
                        st.warning("Query executed, but no data was returned.")
                        st.session_state.messages.append({"role": "assistant", "content": "Query returned no data."})
                    
                    
                except Exception as e:
                    st.error(f"Error executing SQL query: {e}")
                    st.session_state.messages.append({"role": "assistant", "content": f"Failed to execute SQL query: {e}"})

            st.session_state.generated_sql = None
            st.session_state.awaiting_confirmation = False
            st.rerun() # Rerun to clear confirmation buttons and allow new input

    with col2:
        if st.button("❓ Explain the Query"):
            st.session_state.messages.append({"role": "user", "content": f"Explain this SQL query: ```sql\n{st.session_state.generated_sql}\n```"})
            with st.chat_message("user"):
                st.markdown(f"Explain this SQL query: ```sql\n{st.session_state.generated_sql}\n```")
            with st.chat_message("assistant"):
                with st.spinner("Getting explanation..."):
                    explanation = get_sql_explanation(st.session_state.generated_sql)
                    st.session_state.messages.append({"role": "assistant", "content": explanation})
                    st.markdown(explanation)
            # No rerun here to keep the chat input stable and confirmation buttons visible.

    with col3:
        if st.button("✏️ Refine Request"):
            st.info("Please provide more details to refine the SQL query.")
            st.session_state.messages.append({"role": "assistant", "content": "User chose to refine the request."})
            st.session_state.generated_sql = None
            st.session_state.awaiting_confirmation = False
            st.rerun()

# --- Chat Input and Logic (Always rendered at the bottom) ---
if prompt := st.chat_input("Ask a question about your data..."):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Generating SQL..."):
            # Pass the dynamically fetched schema to the LLM service
            llm_response_text = call_llm_api(st.session_state.messages, st.session_state.db_schema)
            
            # Immediately add and display the LLM's response
            st.session_state.messages.append({"role": "assistant", "content": llm_response_text})
            st.markdown(llm_response_text)


            sql_code = extract_sql_from_response(llm_response_text)

            if sql_code:
                st.session_state.generated_sql = sql_code
                st.session_state.awaiting_confirmation = True
                # RERUN HERE: This is crucial for the confirmation buttons to appear immediately
                # after SQL is generated by the LLM.
                st.rerun() 
            else:
                st.session_state.generated_sql = None
                st.session_state.awaiting_confirmation = False


# --- Instructions for Running the App ---
st.sidebar.header("How to Run This App")
st.sidebar.markdown("""
To run this application, you need to save each code block into its respective file:

1.  **`config.py`**: Contains shared configuration (API URL, LLM Model, API Key placeholder).
2.  **`llm_service.py`**: Handles all interactions with the LLM, now accepting dynamic schema.
3.  **`database_service.py`**: Manages database connection and query execution, and now includes `fetch_db_schema`.
4.  **`main_app.py`**: The main Streamlit application, which orchestrates by fetching and passing the schema.

Ensure all files are in the same directory.

**Important:** In `config.py`, replace `"YOUR_LLM_API_KEY_HERE"` with your actual API key for `https://llm.w10e.com`.

**Installation:**
```bash
pip install streamlit requests pandas
```

**Run the app:**
```bash
streamlit run main_app.py
```
""")
